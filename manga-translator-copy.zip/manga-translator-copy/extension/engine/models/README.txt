comictextdetector-fp16.onnx

Text detection model from comic-text-detector by dmMaze
(https://github.com/dmMaze/comic-text-detector), as exported to ONNX by
manga-image-translator (https://github.com/zyddnys/manga-image-translator,
release beta-0.3, comictextdetector.pt.onnx), converted to half precision
(float16) with onnxconverter-common for faster GPU inference in the browser.

See those projects for the model's license (GPL-3.0 at the time of writing).
