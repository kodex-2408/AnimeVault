// Image -> detected boxes -> Gemini translation -> overlay blocks, with caching.
import { TextDetector, readingOrder } from "./detector.js";
import { computeRegions } from "./layout.js";
import { GeminiTranslator, OpenRouterTranslator, OPENROUTER_LABEL, TranslatorError, renderInputs } from "./translator.js";

// Bump when detection/layout/translation output changes, to invalidate cached results.
const PIPELINE_VERSION = "7";
const MAX_CONTEXTS = 100;
const CONTEXT_LINES = 16;

// ------------------------------------------------------------------ cache (IndexedDB)
// Best effort: if the browser can't open the database, pages are still translated,
// just not cached.
const db = new Promise((resolve) => {
  try {
    const req = indexedDB.open("manga-translator", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("results");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => {
      console.warn("[cache] unavailable:", req.error);
      resolve(null);
    };
  } catch (e) {
    console.warn("[cache] unavailable:", e);
    resolve(null);
  }
});

async function cacheGet(key) {
  const d = await db;
  if (!d) return undefined;
  return new Promise((resolve) => {
    const r = d.transaction("results").objectStore("results").get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => resolve(undefined);
  });
}

async function cachePut(key, value) {
  const d = await db;
  if (!d) return;
  return new Promise((resolve) => {
    const tx = d.transaction("results", "readwrite");
    tx.objectStore("results").put(value, key);
    tx.oncomplete = tx.onerror = () => resolve();
  });
}

async function sha256(bytes, suffix) {
  const extra = new TextEncoder().encode(suffix);
  const all = new Uint8Array(bytes.byteLength + extra.length);
  all.set(new Uint8Array(bytes), 0);
  all.set(extra, bytes.byteLength);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", all));
  return [...digest.slice(0, 16)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ------------------------------------------------------------------ engine
export class Engine {
  constructor() {
    this.detector = null;
    this.detectorReady = TextDetector.create().then((d) => (this.detector = d));
    this.detectorReady.catch((e) => (this.startError = e));
    this.translator = new GeminiTranslator();
    this.openrouter = new OpenRouterTranslator();
    this.inflight = new Map();
    this.context = new Map(); // reading context (series/chapter) -> recent lines, for consistency
  }

  status(provider) {
    return {
      device: this.detector?.device || (this.startError ? "failed" : "loading"),
      error: this.startError ? String(this.startError.message || this.startError) : null,
      models: provider === "openrouter" ? [OPENROUTER_LABEL] : this.translator.ranked(), // fastest first
    };
  }

  /** bytes: ArrayBuffer of an image. Returns the overlay result (same format as before). */
  async process({ bytes, src, tgt, ctx, apiKey, provider = "gemini" }) {
    // Each translation service has its own cached results.
    const key = await sha256(bytes, `|${src}|${tgt}|${PIPELINE_VERSION}${provider === "gemini" ? "" : `|${provider}`}`);
    const cached = await cacheGet(key);
    if (cached) return { ...cached, cached: true };
    if (this.inflight.has(key)) return this.inflight.get(key);
    const job = this.run(bytes, src, tgt, ctx, apiKey, provider).then(async (result) => {
      await cachePut(key, result);
      return result;
    });
    this.inflight.set(key, job);
    try {
      return await job;
    } finally {
      this.inflight.delete(key);
    }
  }

  async run(bytes, src, tgt, ctx, apiKey, provider) {
    const t0 = performance.now();
    let bitmap;
    try {
      bitmap = await createImageBitmap(new Blob([bytes]));
    } catch (e) {
      throw new TranslatorError(`Cannot decode image: ${e.message}`);
    }
    const { width: w, height: h } = bitmap;
    try {
      await this.detectorReady;
      let boxes = await this.detector.detect(bitmap, w, h);
      const st = boxes.stats;
      boxes = readingOrder(boxes, src === "ja" || src === "auto");
      const result = {
        width: w, height: h, blocks: [],
        timings: {
          detect: +((performance.now() - t0) / 1000).toFixed(2), device: this.detector.device, tiles: st.tiles,
          pre_ms: Math.round(st.pre), infer_ms: Math.round(st.infer), post_ms: Math.round(st.post),
        },
      };
      if (!boxes.length) return result;

      if (!this.context.has(ctx) && this.context.size >= MAX_CONTEXTS) {
        this.context.delete(this.context.keys().next().value); // drop the oldest reading context
      }
      const hist = this.context.get(ctx) || [];
      this.context.set(ctx, hist);

      const t1 = performance.now();
      const images = await renderInputs(bitmap, w, h, boxes);
      const translator = provider === "openrouter" ? this.openrouter : this.translator;
      const items = await translator.translate({ apiKey, images, n: boxes.length, src, tgt, context: [...hist] });
      result.timings.translate = +((performance.now() - t1) / 1000).toFixed(2);

      const canvas = new OffscreenCanvas(w, h);
      const g = canvas.getContext("2d", { willReadFrequently: true });
      g.drawImage(bitmap, 0, 0);
      const regions = computeRegions(g.getImageData(0, 0, w, h), boxes);
      const byId = new Map(items.map((it) => [it.id, it]));
      boxes.forEach((b, i) => {
        const it = byId.get(i);
        const r = regions[i];
        if (!it || it.kind === "none" || !it.translation.trim()) return;
        const round = (v) => Math.round(v * 1e5) / 1e5;
        result.blocks.push({
          // Normalised to the image size so the overlay can scale freely.
          x: round(r.x1 / w), y: round(r.y1 / h), w: round((r.x2 - r.x1) / w), h: round((r.y2 - r.y1) / h),
          fill: r.fill, color: r.color, bubble: r.bubble, halo: r.halo,
          // The shape to paint over (bubble interior, or the letters over artwork), and
          // where the text goes, as fractions of this block.
          mask: r.mask,
          text: {
            x: round((r.text.x1 - r.x1) / (r.x2 - r.x1)), y: round((r.text.y1 - r.y1) / (r.y2 - r.y1)),
            w: round((r.text.x2 - r.text.x1) / (r.x2 - r.x1)), h: round((r.text.y2 - r.text.y1) / (r.y2 - r.y1)),
          },
          source: it.source, translation: it.translation.trim(), kind: it.kind,
        });
        if (["dialogue", "thought", "narration"].includes(it.kind) && it.source) {
          hist.push(`${it.source} => ${it.translation.trim()}`);
          if (hist.length > CONTEXT_LINES) hist.shift();
        }
      });
      result.timings.total = +((performance.now() - t0) / 1000).toFixed(2);
      return result;
    } finally {
      bitmap.close();
    }
  }
}
