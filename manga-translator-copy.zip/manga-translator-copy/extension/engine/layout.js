// Overlay layout. For each detected text box, decide:
//  - what to paint over, to hide the original text: the speech bubble's real shape
//    (every lobe of it, glyph holes included, never past its outline), or, for text
//    written over artwork, just the letters themselves, slightly thickened;
//  - where the translation goes: the largest rectangle that fits inside that shape;
//  - which colours to use, matching the bubble.
// Shapes are sent to the page as run-length-encoded masks and painted on a canvas.
//
// `img` is { data: RGBA bytes, width, height } (ImageData).

const hex = (c) => "#" + c.map((v) => Math.trunc(v).toString(16).padStart(2, "0")).join("");
const textColor = (c) => (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] > 140 ? "#000000" : "#ffffff");
const MASK_MAX_SIDE = 256; // masks are stored at most this many pixels across

/** Flood-fill from seeds within a window around the box. Pixels within ±20 per channel
 *  of the seed's colour, 4-connected. Returns the filled mask (window coordinates) and
 *  its bounds. `leaked` means the fill reached the window edge (inside the image): it
 *  ran into background, a white page margin or similar, not a closed bubble. */
function fill(img, b, seeds, margin) {
  const { data, width: w, height: h } = img;
  const m = Math.trunc(margin * Math.max(b.w, b.h)) + 8;
  const wx1 = Math.max(0, Math.trunc(b.x1) - m), wy1 = Math.max(0, Math.trunc(b.y1) - m);
  const wx2 = Math.min(w, Math.trunc(b.x2) + m), wy2 = Math.min(h, Math.trunc(b.y2) + m);
  const ww = wx2 - wx1, wh = wy2 - wy1;
  const mask = new Uint8Array(ww * wh);
  const stack = new Int32Array(ww * wh);
  const visited = new Int32Array(ww * wh); // per-seed marker: each seed's fill is independent
  let seed = 0;
  for (const [px, py] of seeds) {
    const lx = px - wx1, ly = py - wy1;
    if (mask[ly * ww + lx]) continue;
    seed++;
    const s = (py * w + px) * 4;
    const r = data[s], g = data[s + 1], bl = data[s + 2];
    let top = 0;
    stack[top++] = ly * ww + lx;
    visited[ly * ww + lx] = seed;
    while (top) {
      const p = stack[--top];
      mask[p] = 1;
      const x = p % ww, y = (p - x) / ww;
      for (let k = 0; k < 4; k++) {
        const nx = k === 0 ? x - 1 : k === 1 ? x + 1 : x, ny = k === 2 ? y - 1 : k === 3 ? y + 1 : y;
        if (nx < 0 || ny < 0 || nx >= ww || ny >= wh) continue;
        const q = ny * ww + nx;
        if (visited[q] === seed) continue;
        const o = ((ny + wy1) * w + nx + wx1) * 4;
        if (Math.abs(data[o] - r) <= 20 && Math.abs(data[o + 1] - g) <= 20 && Math.abs(data[o + 2] - bl) <= 20) {
          visited[q] = seed;
          stack[top++] = q;
        }
      }
    }
  }
  let count = 0, x1 = Infinity, y1 = Infinity, x2 = -1, y2 = -1, leaked = false;
  for (let y = 0; y < wh; y++) {
    for (let x = 0; x < ww; x++) {
      if (!mask[y * ww + x]) continue;
      if ((x === 0 && wx1 > 0) || (x === ww - 1 && wx2 < w) || (y === 0 && wy1 > 0) || (y === wh - 1 && wy2 < h)) leaked = true;
      count++;
      if (x < x1) x1 = x; if (x > x2) x2 = x;
      if (y < y1) y1 = y; if (y > y2) y2 = y;
    }
  }
  return { count, leaked, x1: x1 + wx1, y1: y1 + wy1, x2: x2 + wx1, y2: y2 + wy1, mask, wx1, wy1, ww, wh };
}

/** Flood-fill from seed pixels. Returns { f, closed }: closed = a real bubble (multi-lobe
 *  bubbles are one connected fill, so they come back whole); not closed = the fill ran
 *  into a white margin or similar background, so only the part around the text is
 *  used. Null if it's not a usable fill at all. */
function floodBubble(img, b, seeds) {
  // Most bubbles hug their text, so try a small window first, then a large one.
  const small = fill(img, b, seeds, 0.6);
  if (!small || !small.count) return null;
  if (!small.leaked && looksLikeBubble(small, b, img)) return { f: small, closed: true };
  if (small.leaked) {
    const large = fill(img, b, seeds, 3);
    if (large && !large.leaked && looksLikeBubble(large, b, img)) return { f: large, closed: true };
  }
  return { f: small, closed: false };
}

function looksLikeBubble(f, b, img) {
  const { width: w, height: h } = img;
  const bw = f.x2 - f.x1 + 1, bh = f.y2 - f.y1 + 1;
  // The text box may poke out of the fill where it spans two lobes (the gap between
  // them is artwork), so only require the fill to reach the text box's area broadly.
  const tolX = b.w * 0.2 + 2, tolY = b.h * 0.2 + 2;
  const ok = f.count < b.w * b.h * 15 && bw < w * 0.9 && bh < h * 0.6 &&
    f.count > 0.3 * bw * bh && // solid area, not thin glyph strokes
    f.x1 <= b.x1 + tolX && f.y1 <= b.y1 + tolY && f.x2 >= b.x2 - tolX && f.y2 >= b.y2 - tolY;
  return ok;
}

// ------------------------------------------------------------------ shapes
/** A shape is { x, y, w, h, bits } in image pixels; bits[j * w + i] = 1 inside. */
function bubbleShape(f, b, img, fillColor, clip) {
  const { data, width: W } = img;
  // `clip` (for fills that ran into background) limits the shape to around the text.
  const cx1 = clip ? Math.max(f.x1, clip.x1) : f.x1, cy1 = clip ? Math.max(f.y1, clip.y1) : f.y1;
  const cx2 = clip ? Math.min(f.x2, clip.x2) : f.x2, cy2 = clip ? Math.min(f.y2, clip.y2) : f.y2;
  const x = cx1 - 1, y = cy1 - 1, w = cx2 - cx1 + 3, h = cy2 - cy1 + 3;
  const inFill = new Uint8Array(w * h);
  for (let j = 1; j < h - 1; j++) {
    for (let i = 1; i < w - 1; i++) {
      const lx = x + i - f.wx1, ly = y + j - f.wy1;
      if (lx >= 0 && ly >= 0 && lx < f.ww && ly < f.wh && f.mask[ly * f.ww + lx]) inFill[j * w + i] = 1;
    }
  }
  // Everything not reachable from the border without crossing the fill is inside the
  // bubble: that adds the holes left by the letters, making the bubble one solid shape.
  // The outline is reachable, so it stays outside.
  const outside = floodFromBorder(w, h, (p) => !inFill[p]);
  let bits = new Uint8Array(w * h);
  for (let p = 0; p < w * h; p++) bits[p] = outside[p] ? 0 : 1;
  // Then shave off thin strips the fill crept along (a white shelf edge, a gap in the
  // outline into white clouds...): a bubble is thick, they aren't. Keep only the parts
  // that reach the text.
  const r = Math.max(3, Math.round(Math.min(b.w, b.h) * 0.06));
  bits = dilate(erodeR(bits, w, h, r), w, h, r);
  bits = keepTouching(bits, w, h, Math.floor(b.x1) - x, Math.floor(b.y1) - y, Math.ceil(b.x2) - x, Math.ceil(b.y2) - y);
  // Letters touching the outline are connected to the outside: add text-box pixels
  // that are ink (unlike the bubble colour) and lie right next to the shape.
  const near = dilate(bits, w, h, 3);
  const tx1 = Math.max(0, Math.floor(b.x1) - x), tx2 = Math.min(w - 1, Math.ceil(b.x2) - x);
  const ty1 = Math.max(0, Math.floor(b.y1) - y), ty2 = Math.min(h - 1, Math.ceil(b.y2) - y);
  for (let j = ty1; j <= ty2; j++) {
    for (let i = tx1; i <= tx2; i++) {
      const p = j * w + i;
      if (bits[p] || !near[p]) continue;
      const o = ((y + j) * W + x + i) * 4;
      if (Math.max(Math.abs(data[o] - fillColor[0]), Math.abs(data[o + 1] - fillColor[1]), Math.abs(data[o + 2] - fillColor[2])) > 60) bits[p] = 1;
    }
  }
  // Keep 1 px clear of the outline's anti-aliased edge.
  return { x, y, w, h, bits: erode(bits, w, h) };
}

/** Text over artwork: cover the letters only (ink pixels, thickened), not a box. */
function inkShape(img, b, bg) {
  const { data, width: W, height: H } = img;
  const pad = Math.max(3, Math.round(Math.min(b.w, b.h) * 0.06));
  const x = Math.max(0, Math.floor(b.x1) - pad), y = Math.max(0, Math.floor(b.y1) - pad);
  const w = Math.min(W, Math.ceil(b.x2) + pad) - x, h = Math.min(H, Math.ceil(b.y2) + pad) - y;
  const ink = new Uint8Array(w * h);
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      const o = ((y + j) * W + x + i) * 4;
      if (Math.max(Math.abs(data[o] - bg[0]), Math.abs(data[o + 1] - bg[1]), Math.abs(data[o + 2] - bg[2])) > 48) ink[j * w + i] = 1;
    }
  }
  // Only ink inside the text box itself (the padding is just room for thickening).
  const bx1 = Math.floor(b.x1) - x, bx2 = Math.ceil(b.x2) - x, by1 = Math.floor(b.y1) - y, by2 = Math.ceil(b.y2) - y;
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (i < bx1 || i > bx2 || j < by1 || j > by2) ink[j * w + i] = 0;
  return { x, y, w, h, bits: dilate(ink, w, h, Math.max(2, Math.round(Math.min(b.w, b.h) * 0.04))) };
}

/** Pixels reachable from the border through pixels where pass(p) is true (4-connected). */
function floodFromBorder(w, h, pass) {
  const seen = new Uint8Array(w * h);
  const stack = new Int32Array(w * h);
  let top = 0;
  const push = (p) => { if (!seen[p] && pass(p)) { seen[p] = 1; stack[top++] = p; } };
  for (let i = 0; i < w; i++) { push(i); push((h - 1) * w + i); }
  for (let j = 0; j < h; j++) { push(j * w); push(j * w + w - 1); }
  while (top) {
    const p = stack[--top];
    const i = p % w, j = (p - i) / w;
    if (i > 0) push(p - 1);
    if (i < w - 1) push(p + 1);
    if (j > 0) push(p - w);
    if (j < h - 1) push(p + w);
  }
  return seen;
}

function dilate(bits, w, h, r) {
  const tmp = new Uint8Array(w * h), out = new Uint8Array(w * h);
  for (let j = 0; j < h; j++) {
    let c = 0;
    for (let i = 0; i < Math.min(r, w); i++) c += bits[j * w + i];
    for (let i = 0; i < w; i++) {
      if (i + r < w) c += bits[j * w + i + r];
      if (i - r - 1 >= 0) c -= bits[j * w + i - r - 1];
      tmp[j * w + i] = c > 0 ? 1 : 0;
    }
  }
  for (let i = 0; i < w; i++) {
    let c = 0;
    for (let j = 0; j < Math.min(r, h); j++) c += tmp[j * w + i];
    for (let j = 0; j < h; j++) {
      if (j + r < h) c += tmp[(j + r) * w + i];
      if (j - r - 1 >= 0) c -= tmp[(j - r - 1) * w + i];
      out[j * w + i] = c > 0 ? 1 : 0;
    }
  }
  return out;
}

function erode(bits, w, h) {
  const out = new Uint8Array(w * h);
  for (let j = 1; j < h - 1; j++) {
    for (let i = 1; i < w - 1; i++) {
      const p = j * w + i;
      out[p] = bits[p] & bits[p - 1] & bits[p + 1] & bits[p - w] & bits[p + w];
    }
  }
  return out;
}

/** Erosion with a (2r+1) square: the complement of dilating the complement. */
function erodeR(bits, w, h, r) {
  const inv = new Uint8Array(w * h);
  for (let p = 0; p < w * h; p++) inv[p] = bits[p] ? 0 : 1;
  const d = dilate(inv, w, h, r);
  for (let p = 0; p < w * h; p++) inv[p] = d[p] ? 0 : 1;
  return inv;
}

/** Keep the 4-connected parts that reach into the given rectangle (the text box) and
 *  are at least a quarter the size of the largest such part: a bubble, even one with
 *  several lobes, is one big part; stray patches of matching colour are small. */
function keepTouching(bits, w, h, rx1, ry1, rx2, ry2) {
  const label = new Int32Array(w * h);
  const stack = new Int32Array(w * h);
  const sizes = [0];
  rx1 = Math.max(0, rx1); ry1 = Math.max(0, ry1); rx2 = Math.min(w - 1, rx2); ry2 = Math.min(h - 1, ry2);
  for (let j = ry1; j <= ry2; j++) {
    for (let i = rx1; i <= rx2; i++) {
      const s = j * w + i;
      if (!bits[s] || label[s]) continue;
      const id = sizes.length;
      let top = 0, size = 0;
      stack[top++] = s;
      label[s] = id;
      while (top) {
        const p = stack[--top];
        size++;
        const x = p % w;
        if (x > 0 && bits[p - 1] && !label[p - 1]) { label[p - 1] = id; stack[top++] = p - 1; }
        if (x < w - 1 && bits[p + 1] && !label[p + 1]) { label[p + 1] = id; stack[top++] = p + 1; }
        if (p - w >= 0 && bits[p - w] && !label[p - w]) { label[p - w] = id; stack[top++] = p - w; }
        if (p + w < w * h && bits[p + w] && !label[p + w]) { label[p + w] = id; stack[top++] = p + w; }
      }
      sizes.push(size);
    }
  }
  const biggest = Math.max(0, ...sizes);
  const keep = sizes.map((n) => n > 0 && n >= biggest * 0.25);
  const out = new Uint8Array(w * h);
  for (let p = 0; p < w * h; p++) if (label[p] && keep[label[p]]) out[p] = 1;
  return out;
}

/** Text over artwork has no bubble to fit in, and a vertical Japanese column is far
 *  too narrow for English: widen the text area to at least 80% of its height, centred
 *  on the original. The page shows it with an outline in the background colour. */
function overArt(t, imgW, imgH) {
  // Also at least a small fraction of the page, so a tiny detection still gets readable text.
  const minW = Math.max((t.y2 - t.y1) * 0.8, imgW * 0.06);
  const minH = Math.max(t.y2 - t.y1, imgW * 0.04);
  const grow = (a1, a2, min, max) => {
    if (a2 - a1 >= min) return [a1, a2];
    const s = Math.max(0, Math.min(max - min, (a1 + a2) / 2 - min / 2));
    return [s, Math.min(max, s + min)];
  };
  const [x1, x2] = grow(t.x1, t.x2, minW, imgW);
  const [y1, y2] = grow(t.y1, t.y2, minH, imgH);
  return { x1, y1, x2, y2 };
}

/** The largest axis-aligned rectangle inside the shape (classic histogram method). */
function largestRect(s) {
  const { w, h, bits } = s;
  const heights = new Int32Array(w);
  const stack = new Int32Array(w + 1);
  let best = { area: 0, x1: 0, y1: 0, x2: 0, y2: 0 };
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) heights[i] = bits[j * w + i] ? heights[i] + 1 : 0;
    let top = 0;
    for (let i = 0; i <= w; i++) {
      const cur = i < w ? heights[i] : 0;
      while (top && heights[stack[top - 1]] >= cur) {
        const hh = heights[stack[--top]];
        const left = top ? stack[top - 1] + 1 : 0;
        const area = hh * (i - left);
        if (area > best.area) best = { area, x1: left, y1: j - hh + 1, x2: i - 1, y2: j };
      }
      stack[top++] = i;
    }
  }
  return { x1: s.x + best.x1, y1: s.y + best.y1, x2: s.x + best.x2 + 1, y2: s.y + best.y2 + 1 };
}

/** Tight bounds of the set pixels, and the mask cropped to them, downsampled and
 *  run-length encoded: runs alternate off/on, starting with off. */
function encode(s) {
  let x1 = s.w, y1 = s.h, x2 = -1, y2 = -1;
  for (let j = 0; j < s.h; j++) {
    for (let i = 0; i < s.w; i++) {
      if (!s.bits[j * s.w + i]) continue;
      if (i < x1) x1 = i; if (i > x2) x2 = i;
      if (j < y1) y1 = j; if (j > y2) y2 = j;
    }
  }
  if (x2 < 0) return null;
  const bw = x2 - x1 + 1, bh = y2 - y1 + 1;
  const scale = Math.min(1, MASK_MAX_SIDE / Math.max(bw, bh));
  const mw = Math.max(1, Math.round(bw * scale)), mh = Math.max(1, Math.round(bh * scale));
  const runs = [];
  let cur = 0, len = 0;
  for (let j = 0; j < mh; j++) {
    const sj = y1 + Math.min(bh - 1, Math.floor((j + 0.5) / scale));
    for (let i = 0; i < mw; i++) {
      const si = x1 + Math.min(bw - 1, Math.floor((i + 0.5) / scale));
      const v = s.bits[sj * s.w + si];
      if (v === cur) len++;
      else { runs.push(len); cur = v; len = 1; }
    }
  }
  runs.push(len);
  return { x1: s.x + x1, y1: s.y + y1, x2: s.x + x2 + 1, y2: s.y + y2 + 1, mask: { w: mw, h: mh, runs: runs.join(",") } };
}

// ------------------------------------------------------------------ regions
export function computeRegions(img, boxes) {
  const { data, width: w, height: h } = img;
  const regions = [];
  for (const b of boxes) {
    const x1 = Math.max(0, Math.trunc(b.x1)), y1 = Math.max(0, Math.trunc(b.y1));
    const x2 = Math.min(w - 1, Math.trunc(b.x2)), y2 = Math.min(h - 1, Math.trunc(b.y2));
    // Inside a text box most pixels are the bubble background, so the box interior
    // gives both the bubble colour and flood-fill seeds.
    const sy = Math.max(1, Math.trunc((y2 - y1) / 12)), sx = Math.max(1, Math.trunc((x2 - x1) / 12));
    const pts = [], cols = [];
    for (let y = y1; y < y2; y += sy) {
      for (let x = x1; x < x2; x += sx) {
        const o = (y * w + x) * 4;
        pts.push([x, y]);
        cols.push([data[o], data[o + 1], data[o + 2]]);
      }
    }
    const n = cols.length;
    const close = cols.map((a) => cols.map((c) =>
      Math.max(Math.abs(a[0] - c[0]), Math.abs(a[1] - c[1]), Math.abs(a[2] - c[2])) < 24));
    // Try the two most common colours: dense bold glyphs can outnumber the
    // background in a tight single-line box.
    const remaining = new Array(n).fill(true);
    let found = null, firstFill = null;
    for (let round = 0; round < 2 && remaining.some(Boolean); round++) {
      let best = 0, bestCount = -1;
      for (let i = 0; i < n; i++) {
        const c = remaining[i] ? close[i].reduce((s, v, j) => s + (v && remaining[j] ? 1 : 0), 0) : 0;
        if (c > bestCount) [best, bestCount] = [i, c];
      }
      const near = close[best].map((v, j) => v && remaining[j]);
      const members = cols.filter((_, j) => near[j]);
      const fillColor = [0, 1, 2].map((k) => members.reduce((s, c) => s + c[k], 0) / members.length);
      firstFill ??= fillColor;
      if (members.length / n > 0.2) {
        const bubble = floodBubble(img, b, pts.filter((_, j) => near[j]));
        if (bubble) {
          found = { ...bubble, fillColor };
          break;
        }
      }
      near.forEach((v, j) => v && (remaining[j] = false));
    }

    const bg = found ? found.fillColor : firstFill || [255, 255, 255];
    // A fill that ran into background (white page margin, plain panel) is used only
    // around the text: painting the same colour over it is invisible, and the text
    // stays where the original was.
    const m = Math.round(Math.max(b.w, b.h) * 0.12);
    const clip = found && !found.closed
      ? { x1: Math.floor(b.x1) - m, y1: Math.floor(b.y1) - m, x2: Math.ceil(b.x2) + m, y2: Math.ceil(b.y2) + m }
      : null;
    const shape = found ? bubbleShape(found.f, b, img, bg, clip) : inkShape(img, b, bg);
    // Text goes in the largest rectangle inside a bubble; over artwork, on the text box.
    const pad = Math.max(2, Math.round(Math.min(b.w, b.h) * 0.04));
    const textBox = { x1: Math.max(0, b.x1 - pad), y1: Math.max(0, b.y1 - pad), x2: Math.min(w, b.x2 + pad), y2: Math.min(h, b.y2 + pad) };
    const enc = encode(shape);
    if (!enc) { // nothing to paint (shouldn't happen): a plain box over the text
      regions.push({ ...textBox, mask: null, text: textBox, fill: hex(bg), color: textColor(bg), bubble: false });
      continue;
    }
    // A fill with no room for text (e.g. it ran inside outlined white lettering drawn
    // over the art) is treated like text over artwork.
    const area = (r) => (r.x2 - r.x1) * (r.y2 - r.y1);
    const inside = found && largestRect(shape);
    const side = (r) => Math.min(r.x2 - r.x1, r.y2 - r.y1);
    const roomy = inside && (area(inside) >= area(textBox) * 0.25 || side(inside) >= side(textBox) * 0.6);
    regions.push({
      x1: enc.x1, y1: enc.y1, x2: enc.x2, y2: enc.y2, mask: enc.mask, text: roomy ? inside : overArt(textBox, w, h),
      fill: hex(bg), color: textColor(bg), bubble: !!found?.closed && roomy, halo: !roomy,
    });
  }
  return regions;
}
